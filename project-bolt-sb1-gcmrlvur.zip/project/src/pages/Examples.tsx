import React from 'react';
import { Parallax } from 'react-parallax';

export default function Examples() {
  return (
    <div>
      <Parallax
        blur={0}
        bgImage="https://images.unsplash.com/photo-1686191128892-3b37a5925cbb?auto=format&fit=crop&q=80"
        strength={200}
      >
        <div className="min-h-screen pt-20 px-4">
          <div className="max-w-4xl mx-auto bg-white bg-opacity-95 p-8 rounded-lg shadow-lg">
            <h1 className="text-4xl font-bold mb-8">Примеры успешного применения Generative AI</h1>

            <div className="space-y-6">
              {/* Existing content */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">GitHub Copilot</h2>
                <p className="mb-4">
                  Инструмент для автоматического написания кода, который помогает разработчикам
                  быстрее создавать программное обеспечение.
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Увеличение продуктивности разработчиков на 55%</li>
                  <li>Более 40% кода генерируется автоматически</li>
                  <li>Поддержка множества языков программирования</li>
                </ul>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">DALL-E в дизайне</h2>
                <p className="mb-4">
                  Использование DALL-E для создания уникальных изображений и концепт-артов.
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Создание уникальных иллюстраций для книг</li>
                  <li>Генерация концепт-артов для игр</li>
                  <li>Разработка рекламных материалов</li>
                </ul>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">ChatGPT в образовании</h2>
                <p className="mb-4">
                  Применение ChatGPT для создания образовательных материалов и помощи в обучении.
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Создание персонализированных учебных планов</li>
                  <li>Помощь в объяснении сложных концепций</li>
                  <li>Генерация практических заданий</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </Parallax>
    </div>
  );
}