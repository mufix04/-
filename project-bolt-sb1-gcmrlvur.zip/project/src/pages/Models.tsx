import React from 'react';
import { Parallax } from 'react-parallax';

export default function Models() {
  return (
    <div>
      <Parallax
        blur={0}
        bgImage="https://images.unsplash.com/photo-1675271591211-126ef0182f55?auto=format&fit=crop&q=80"
        strength={200}
      >
        <div className="min-h-screen pt-20 px-4">
          <div className="max-w-4xl mx-auto bg-white bg-opacity-95 p-8 rounded-lg shadow-lg">
            <h1 className="text-4xl font-bold mb-8">Современные модели Generative AI</h1>

            <div className="space-y-6">
              {/* Existing content */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">Языковые модели</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold text-blue-600">GPT (ChatGPT)</h3>
                    <p>Мощная языковая модель для генерации текста и диалогов.</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-blue-600">BERT</h3>
                    <p>Модель для понимания контекста и анализа естественного языка.</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">Модели генерации изображений</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold text-blue-600">DALL-E</h3>
                    <p>Создание изображений по текстовому описанию.</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-blue-600">Stable Diffusion</h3>
                    <p>Открытая модель для генерации и редактирования изображений.</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">Музыкальные модели</h2>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-xl font-semibold text-blue-600">MuseNet</h3>
                    <p>Генерация музыкальных композиций в различных стилях.</p>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-blue-600">Amper</h3>
                    <p>Создание музыки для различных медиа-проектов.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Parallax>
    </div>
  );
}