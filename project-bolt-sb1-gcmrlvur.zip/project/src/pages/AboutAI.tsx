import React from 'react';
import { Parallax } from 'react-parallax';

export default function AboutAI() {
  return (
    <div>
      <Parallax
        blur={0}
        bgImage="https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80"
        strength={200}
      >
        <div className="min-h-screen pt-20 px-4">
          <div className="max-w-4xl mx-auto bg-white bg-opacity-95 p-8 rounded-lg shadow-lg">
            {/* Existing content */}
            <h1 className="text-4xl font-bold mb-8">Что такое Generative AI?</h1>
            
            <div className="mb-8">
              <p className="text-lg mb-4">
                Generative AI (Генеративный ИИ) - это тип искусственного интеллекта, способный создавать новый контент на основе обучающих данных. Он использует сложные алгоритмы машинного обучения для генерации текста, изображений, музыки и других форм контента.
              </p>
              
              <h2 className="text-2xl font-semibold mt-6 mb-4">Ключевые особенности:</h2>
              <ul className="list-disc pl-6 space-y-2">
                <li>Способность к обучению на больших наборах данных</li>
                <li>Генерация уникального контента</li>
                <li>Адаптация к различным задачам и контекстам</li>
                <li>Возможность комбинировать различные стили и паттерны</li>
              </ul>
            </div>

            <div>
              <h2 className="text-2xl font-semibold mb-4">Преимущества и ограничения</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-xl font-semibold mb-3 text-green-600">Преимущества</h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Быстрая генерация контента</li>
                    <li>Масштабируемость решений</li>
                    <li>Снижение затрат на создание контента</li>
                    <li>Персонализация под потребности пользователя</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold mb-3 text-red-600">Ограничения</h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Зависимость от качества обучающих данных</li>
                    <li>Этические вопросы использования</li>
                    <li>Возможные ошибки и неточности</li>
                    <li>Высокие требования к вычислительным ресурсам</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Parallax>
    </div>
  );
}