import React from 'react';
import { Parallax } from 'react-parallax';

export default function Applications() {
  return (
    <div>
      <Parallax
        blur={0}
        bgImage="https://images.unsplash.com/photo-1676299081847-824916de030a?auto=format&fit=crop&q=80"
        strength={200}
      >
        <div className="min-h-screen pt-20 px-4">
          <div className="max-w-4xl mx-auto bg-white bg-opacity-95 p-8 rounded-lg shadow-lg">
            <h1 className="text-4xl font-bold mb-8">Области применения Generative AI</h1>

            <div className="grid gap-6">
              {/* Existing content */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">Искусство и дизайн</h2>
                <p className="mb-4">Создание изображений, иллюстраций и дизайн-концепций по текстовому описанию.</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Генерация художественных работ</li>
                  <li>Создание логотипов и брендинга</li>
                  <li>Дизайн интерьеров</li>
                </ul>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">Разработка программного обеспечения</h2>
                <p className="mb-4">Помощь в написании и оптимизации кода, генерация документации.</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Автоматическое написание кода</li>
                  <li>Рефакторинг существующего кода</li>
                  <li>Создание технической документации</li>
                </ul>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-2xl font-semibold mb-4">Контент-маркетинг</h2>
                <p className="mb-4">Создание разнообразного контента для маркетинговых целей.</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Написание статей и постов</li>
                  <li>Генерация рекламных текстов</li>
                  <li>Создание email-рассылок</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </Parallax>
    </div>
  );
}