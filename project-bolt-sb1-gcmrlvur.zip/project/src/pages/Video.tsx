import React from 'react';
import { Parallax } from 'react-parallax';
import videoFile from '../assets/videos/generative-ai.mp4';

export default function Video() {
  return (
    <div>
      <Parallax
        blur={0}
        bgImage="https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?auto=format&fit=crop&q=80"
        strength={200}
      >
        <div className="min-h-screen pt-20 px-4">
          <div className="max-w-4xl mx-auto bg-white bg-opacity-95 p-8 rounded-lg shadow-lg">
            <h1 className="text-4xl font-bold mb-8">Видео о Generative AI</h1>
            
            <div className="aspect-w-16 aspect-h-9">
              <video
                className="w-full h-[500px] rounded-lg shadow-lg object-cover"
                controls
                preload="metadata"
              >
                <source src={videoFile} type="video/mp4" />
                Ваш браузер не поддерживает видео тег.
              </video>
            </div>
            
            <div className="mt-8">
              <h2 className="text-2xl font-semibold mb-4">О видео</h2>
              <p className="text-lg">
                В этом видео рассказывается о том, что такое генеративный искусственный интеллект,
                как он работает и какие возможности открывает для различных областей применения.
              </p>
            </div>
          </div>
        </div>
      </Parallax>
    </div>
  );
}