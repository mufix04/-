import React from 'react';
import { Parallax } from 'react-parallax';

export default function HomePage() {
  return (
    <div className="pt-16">
      <Parallax
        blur={0}
        bgImage="https://images.unsplash.com/photo-1620712943543-bcc4688e7485?auto=format&fit=crop&q=80"
        strength={200}
        className="min-h-screen"
      >
        <div className="min-h-screen flex items-center justify-center">
          <div className="bg-white bg-opacity-90 p-8 rounded-lg max-w-4xl mx-4">
            <h1 className="text-4xl font-bold mb-6">Generative AI: Будущее Творчества</h1>
            <p className="text-lg mb-4">
              Генеративный ИИ - это революционная технология, способная создавать новый контент,
              от изображений и текста до музыки и кода.
            </p>
          </div>
        </div>
      </Parallax>
    </div>
  );
}