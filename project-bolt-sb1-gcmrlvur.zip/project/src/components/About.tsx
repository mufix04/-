import React from 'react';

export default function About() {
  return (
    <div className="min-h-screen bg-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-8 text-center">О нас</h2>
        <div className="bg-gray-50 p-8 rounded-lg shadow-lg">
          <p className="text-lg mb-6">
            Данный проект был разработан студентами группы 2бИТС3:
          </p>
          <ul className="space-y-4">
            <li className="flex items-center space-x-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>Авраменко Алексей</span>
            </li>
            <li className="flex items-center space-x-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>Осыка Роман</span>
            </li>
            <li className="flex items-center space-x-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>Лукашкин Никита</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}