import React from 'react';
import { Link } from 'react-router-dom';
import { Brain } from 'lucide-react';

export default function Navigation() {
  return (
    <nav className="bg-white shadow-lg fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Brain className="h-8 w-8 text-blue-600" />
            <span className="ml-2 text-xl font-bold">Generative AI</span>
          </div>
          <div className="flex items-center space-x-6">
            <Link to="/" className="hover:text-blue-600">Главная</Link>
            <Link to="/about-ai" className="hover:text-blue-600">О Generative AI</Link>
            <Link to="/applications" className="hover:text-blue-600">Применение</Link>
            <Link to="/models" className="hover:text-blue-600">Модели</Link>
            <Link to="/examples" className="hover:text-blue-600">Примеры</Link>
            <Link to="/video" className="hover:text-blue-600">Видео</Link>
            <Link to="/about" className="hover:text-blue-600">О нас</Link>
          </div>
        </div>
      </div>
    </nav>
  );
}