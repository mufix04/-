import React, { useState } from 'react';
import { X } from 'lucide-react';

export default function ChatGPT() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-blue-600 text-white p-4 rounded-full shadow-lg hover:bg-blue-700 transition-colors"
      >
        Открыть ChatGPT
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-2xl h-[600px] relative">
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-2 right-2 p-2 hover:bg-gray-100 rounded-full"
            >
              <X size={24} />
            </button>
            <iframe
              src="https://chat.openai.com/"
              className="w-full h-full rounded-lg"
              title="ChatGPT"
            />
          </div>
        </div>
      )}
    </>
  );
}