import React from 'react';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <p>© 2024 Generative AI. Разработано группой 2бИТС3</p>
      </div>
    </footer>
  );
}