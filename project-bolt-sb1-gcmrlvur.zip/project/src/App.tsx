import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import ChatGPT from './components/ChatGPT';
import HomePage from './pages/HomePage';
import AboutAI from './pages/AboutAI';
import Applications from './pages/Applications';
import Models from './pages/Models';
import Examples from './pages/Examples';
import Video from './pages/Video';
import About from './components/About';

function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about-ai" element={<AboutAI />} />
            <Route path="/applications" element={<Applications />} />
            <Route path="/models" element={<Models />} />
            <Route path="/examples" element={<Examples />} />
            <Route path="/video" element={<Video />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </main>
        <Footer />
        <ChatGPT />
      </div>
    </Router>
  );
}

export default App;